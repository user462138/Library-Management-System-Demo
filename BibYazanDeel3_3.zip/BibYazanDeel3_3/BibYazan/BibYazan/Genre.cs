﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibYazan
{
    internal enum Genre
    {
        Fiction,
        NonFiction,
        Mystery,
        ScienceFiction,
        Fantasy,
        Romance,
        Thriller,
        Horror,
        Adventure,
        Dystopian,
        History,
        Psychology,
        SelfHelp,
        Schoolboek,
        Other
    }
}
